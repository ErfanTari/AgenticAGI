# Memory Index
# Auto-maintained. Edit with caution.

WHO.CT-000001: Erfan Tari — Contact entry for Erfan Tari
WHO.CT-000010: Sara — Developer
WHO.CT-000011: James — Developer
WHO.CT-000012: James Chen — Team Lead
WHO.CT-000002: Bob Jones — Summary for Bob Jones
WHO.CT-000003: Charlie — Summary for Charlie
WHO.CT-000004: Dave — Summary for Dave
PLAN.EX-000001: Create a file called hello.txt in workspace/TestProject with content "Hello World". — Execution state for: Create a file called hello.txt in workspace/TestProject with content "Hello Worl
WHEN.RF-000002: Reflection: I started working on a new project today called Te [07:07:12] — Acknowledged.
WHO.CT-000078: Alice — Contact: Alice
WHO.CT-000079: Bob — Contact: Bob
PLAN.PJ-000008: TestProject42 — Project: TestProject42
WHAT.PJ-000075: Zaraban Dashboard — New project: Zaraban Dashboard
HOW.PR-000001: Argyll — Argyll
HOW.PR-000036: Web scraper that saves results to memory — Python web scraper with memory integration
WHAT.PJ-000014: AgenticAGI Project — Working on the AgenticAGI project
HOW.PR-000052: Milestone Pattern: Create contacts for Alice and Bob — Reusable pattern from Create contacts for Alice and Bob
WHEN.EV-000138: Save Alice as a contact and Bob as a contact and create a project called TestProject42. — Create contacts for Alice and Bob — success — Save Alice as a contact and Bob as a contact and create a pr
HOW.PR-000053: Milestone Pattern: Contacts created — Reusable pattern from Contacts created
HOW.PR-000044: Milestone Pattern: Complete task — Reusable pattern from Complete task
HOW.PR-000022: Web Scraper for Memory Storage - Updated — Python script to scrape web content and save results to memory
HOW.PR-000039: Pattern: Create an HTML calculator website with Mac OS-like design in — Auto-generated procedure for: Create an HTML calculator website with Mac OS-like design in a 'project_for_test
PLAN.PL-000001: Phase 9 Completion Plan for AgenticAGI — Detailed roadmap to complete Phase 9 development and testing
WHO.CT-000081: Alice Codex 112825 — Contact from CodexStressProject112825 project
WHO.CT-000082: Alice Codex 113421 — Contact for CodexStressProject113421
WHO.CT-000093: Bob Codex 124110 — Contact: Bob Codex 124110
WHO.CT-000094: Charlie B. — Contact for Charlie B.
WHEN.EV-000185: Charlie B. Presentation — Charlie B. will present on Friday.
WHEN.EV-000189: Charlie B. reviewed code — Charlie B. completed a code review.
WHEN.EV-000196: Charlie reviewed code — Charlie completed a code review.
PLAN.EX-000002: Test execution — Test
WHAT.PJ-000001: Test execution — Test
NOW.LOG-000001: Log 2026-03-17 10:21 — just finished the session
WHO.CT-000015: Farzad Hamadi — Software engineer from Tehran interested in AI; personal contact of ERFAN TARI
WHY.MT-000013: Heartbeat — stale_project_brain — 6 project brain(s) not updated in 3+ days
WHY.MT-000003: Heartbeat 2026-03-06 — stale_plan — 2 planning entry/entries stale for 7+ days
HOW.PR-000032: Pattern: Search the web for latest news on AI agents and remember the — Auto-generated procedure for: search the web for latest news on AI agents and remember the key findings
WHEN.EV-000100: Remember the last time the user asked to build a calculator. — Recall Calculator Task — success — Remember the last time the user asked to build a calculator.
WHO.CT-000083: Alice Codex 115404 — Contact: Alice Codex 115404
WHO.CT-000084: Alice Codex 120502 — Contact: Alice Codex 120502
WHO.CT-000075: Sara Ahmadi — Machine learning engineer interested in agent memory systems
WHO.CT-000076: Zaraban — Name meaning and origin: Zaban (Language) + Ravan (Mind), Heartbeat.
WHO.CT-000077: Favorite Color Preference — User's favorite color preference recorded.
WHO.CT-000085: Bob Codex 120502 — Contact: Bob Codex 120502
WHO.CT-000086: Alice Codex 121623 — Contact: Alice Codex 121623
WHO.CT-000087: Bob Codex 121623 — Contact: Bob Codex 121623
WHO.CT-000088: Alice Codex 122608 — Contact: Alice Codex 122608
WHO.CT-000089: Bob Codex 122608 — Contact: Bob Codex 122608
WHO.CT-000090: Alice Codex 123337 — Contact: Alice Codex 123337
WHO.CT-000091: Bob Codex 123337 — Contact: Bob Codex 123337
WHO.CT-000092: Alice Codex 124110 — Contact: Alice Codex 124110
WHAT.PJ-000074: Create Snake Game in HTML — Develop an HTML-based Snake game within a specified project folder.
WHEN.EV-000095: Create an HTML Snake game in the specified directory. — Generate Game Content — success — Create an HTML Snake game in the specified directory. — Gene
WHEN.EV-000096: Create an HTML Snake game in the specified directory. — Save Game Files — success — Create an HTML Snake game in the specified directory. — Save
HOW.PR-000040: Create HTML Snake Game — Procedure to create a basic Snake game in a single HTML file.
HOW.PR-000049: Milestone Pattern: Contacts and Project Created — Reusable pattern from Contacts and Project Created
HOW.PR-000051: Milestone Pattern: Create contacts and project in memory — Reusable pattern from Create contacts and project in memory
WHEN.EV-000103: Save Alice as a contact, Bob as a contact, and create a project called TestProject42 — Complete task — success — Save Alice as a contact, Bob as a contact, and create a proj
WHEN.EV-000089: Create a program that does math — success — Create a program that does math
WHEN.RF-000005: Reflection: Create a program that does math — Thinking Process:
WHAT.PJ-000021: AgenticAGI Landing Page — Create a simple landing page for AgenticAGI project with hero, features, and contact sections.
HOW.PR-000050: Milestone Pattern: Create Express server file — Reusable pattern from Create Express server file
WHO.CT-000095: John Smith — Test contact
WHO.CT-000096: Jane Doe — Test contact 2
WHAT.PJ-000078: Test Project — Project summary
WHO.CT-000097: Integration Test Contact — Test contact for quick-resolve
WHAT.PJ-000079: Tennis 3D Game — 3D tennis game project
NOW.TD-000014: Buy groceries — Grocery shopping task
WHEN.DL-000002: Zaraban Project Deadline — Critical deadline for the Zaraban project
HOW.PR-000023: Pattern: write a web scraper that saves results to memory — Auto-generated procedure for: write a web scraper that saves results to memory
WHEN.EV-000097: Create an HTML Snake game in the specified directory. — Document Procedure — success — Create an HTML Snake game in the specified directory. — Docu
HOW.PR-000034: Write Web Scraper with Memory Storage — Procedure for creating web scrapers that store data in memory
PLAN.EX-000066: Write a Tetris game with combos, overlay text, and 3D objects in the workspace — Execution state for: Write a Tetris game with combos, overlay text, and 3D objects in the workspace
PLAN.EX-000067: Tetris-3D-Spec — Technical spec for 3D Tetris game
WHEN.EV-000203: Write a Tetris game with combos, overlay text, and 3D objects in the workspace — Game Specification and Setup — success — Write a Tetris game with combos, overlay text, and 3D object
WHEN.RF-000086: Reflection: Requesting the creation of a Tetris game with comb [15:42:59] — <|channel>thought
WHEN.RF-000087: Reflection: Write a Tetris game with combos, overlay text, and [15:44:26] — <|channel>thought
WHEN.EV-000090: Create an HTML calculator website with Mac OS-like design in a 'project_for_test' folder — partial — Create an HTML calculator website with Mac OS-like design in
WHEN.EV-000088: Create a basic calculator app and place it in a 'Calculator' folder in the workspace — success — Create a basic calculator app and place it in a 'Calculator'
PLAN.EX-000068: Tetris Implementation Spec — Technical spec for Tetris game with combos and 3D effects
WHAT.KN-000001: Argyll Open Source ICC Calibration Tutorial — Tutorial on using Argyll for ICC color calibration
HOW.PR-000017: Download Neolith Catalog — Procedure for finding and downloading the general catalog from Neolith website.
HOW.PR-000016: Neolith Catalog Download Procedure — Procedure to locate and download Neolith general catalog from their website.
WHEN.EV-000001: Create a procedure for testing ceramic glazes and save it to memory — success — Create a procedure for testing ceramic glazes and save it to
PLAN.EX-000069: Price Dashboard Spec — Live price dashboard for currencies, crypto, gold and silver
PLAN.EX-000070: price_dashboard2-spec — Spec for live price dashboard with crypto, fiat, gold, silver
PLAN.EX-000071: Subway Runner Game Spec — Simple Subway Runner with left/right lane controls
PLAN.EX-000072: Delete existing Subway Runner game and create a regular Subway Runner game — Execution state for: Delete existing Subway Runner game and create a regular Subway Runner game
WHEN.EV-000204: Delete existing Subway Runner game and create a regular Subway Runner game — Delete existing Subway Runner file — success — Delete existing Subway Runner game and create a regular Subw
PLAN.EX-000073: Regular Subway Runner Game Spec — Simple Subway Runner with left/right lane controls and obstacle dodging
WHEN.EV-000205: Delete existing Subway Runner game and create a regular Subway Runner game — Create regular Subway Runner game spec in memory — success — Delete existing Subway Runner game and create a regular Subw
PLAN.EX-000074: subway_runner3-spec — Game spec for subway runner3 with simplified graphics and space controls
PLAN.EX-000075: YouTube Homepage Spec — Specification for YouTube-style homepage
WHEN.CA-000007: Meeting with Sara Ahmadi — Collaboration discussion meeting
WHEN.DL-000001: Review AgenticAGI architecture — Deadline for reviewing AgenticAGI architecture.
PLAN.EX-000076: DVD Screensaver Spec — Specification for DVD screensaver with corner bouncing
WHEN.EV-000094: Create an HTML Snake game in the specified directory. — Setup Project Directory — success — Create an HTML Snake game in the specified directory. — Setu
PLAN.EX-000077: zaraban-portfolio-spec — Spec for Zaraban Portfolio Website with colorful placeholder cards
PLAN.PL-000002: Finish Phase 9 of AgenticAGI — Develop comprehensive plan for completing Phase 9 of AgenticAGI system
PLAN.EX-000078: interior-architecture-site-spec — Specification for modern interior architecture portfolio website with image gallery
PLAN.EX-000079: Create a website for interior architecture using images from the internet — Execution state for: Create a website for interior architecture using images from the internet
PLAN.EX-000080: bouncing-balls-spec — 3D bouncing balls simulation
PLAN.EX-000081: physics-simulation-spec — Spec for physics simulation with falling shapes
WHAT.KN-000011: Memory Architecture Comparison — Comparison of AI agent memory best practices vs our notebook-based system
PLAN.EX-000082: Create a guitar chord simulation app with buttons and keyboard support — Execution state for: Create a guitar chord simulation app with buttons and keyboard support
PLAN.EX-000083: guitar-chord-app-spec — Specification for interactive guitar chord simulation
WHEN.EV-000206: Create a guitar chord simulation app with buttons and keyboard support — Plan and create guitar app specification — success — Create a guitar chord simulation app with buttons and keyboa
WHEN.EV-000207: Create a guitar chord simulation app with buttons and keyboard support — Generate and save guitar app — success — Create a guitar chord simulation app with buttons and keyboa
WHEN.RF-000088: Reflection: Create a guitar chord simulation app with buttons  [08:42:28] — The successful implementation of both button and keyboard controls demonstrates effective integratio
PLAN.EX-000084: physics-shapes-spec — 3D physics simulation with falling shapes
PLAN.EX-000085: physical-shapes-spec — Physics-based 3D shapes falling and bouncing simulation
PLAN.EX-000086: falling-shapes-spec — 3D falling shapes simulation with Three.js
PLAN.EX-000087: falling_shapes.html fix spec — Specification to fix Three.js import and animation loop in falling_shapes.html
PLAN.EX-000088: car-brand-portfolio-spec — Specification for a single-file HTML car brand portfolio
PLAN.EX-000089: zaraban-info — zaraban-info
PLAN.EX-000090: car-portfolio-spec — Spec for car portfolio website
PLAN.EX-000091: car-portfolio-final-spec — Final, robust specification for the car portfolio website
WHO.CT-000080: Charlie Codex 111736 — Contact entry for Charlie Codex 111736
