---
code: WHO.CT-000079
nb: WHO
type: CT
name: Bob
status: active
updated: 2026-04-07
summary: Contact: Bob
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-07
pinned: 0
source: agent
---

# Bob

# Bob

Created from compound entity creation request.

