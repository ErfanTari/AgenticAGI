---
code: PLAN.EX-000081
nb: PLAN
type: EX
name: physics-simulation-spec
status: active
updated: 2026-04-09
summary: Spec for physics simulation with falling shapes
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-09
pinned: 0
source: agent
---

# physics-simulation-spec

## Physics Simulation with Falling Shapes

## Libraries
- Load Matter.js r2.0.0 from CDN (https://cdnjs.cloudflare.com/ajax/libs/matter-js/0.20.0/matter.min.js)
- Use Matter.js for 2D physics simulation (rigid body dynamics, collisions, gravity)

## Visual Features
- Canvas-based rendering with Matter.js Engine and Render
- Dark background (#1a1a2e) with a wooden-textured table at bottom
- Multiple shape types:
  - Circles (balls): Random colors, varying radii (15-40px)
  - Squares: Random colors, varying sizes (30-60px)
  - Triangles: Random colors, varying sizes
  - Rectangles: Random colors, varying dimensions
- Each shape has unique random color from vibrant palette
- Smooth animation at 60fps
- Collision effects with slight bounce

## Interaction Model
- Mouse controls: Click and drag shapes with mouse
- Click empty space to spawn new random shape
- Press 'R' to reset simulation
- Press 'C' to clear all shapes
- Press 'S' to toggle slow-motion (0.5x speed)
- UI controls in top-left corner with buttons for:
  - Spawn Ball
  - Spawn Square
  - Spawn Triangle
  - Reset
  - Clear
  - Slow Motion Toggle

## Physics Settings
- Gravity: Standard Earth gravity (y: 1)
- Restitution (bounciness): 0.7 for shapes, 0.5 for table
- Friction: 0.001 for shapes, 0.5 for table
- Density: 0.001 for all shapes
- Collision filtering to prevent excessive stacking

## Layout
- Canvas fills entire viewport with minimal margins
- UI panel in top-left corner with semi-transparent background
- Instructions displayed at bottom of screen
- Responsive design that adapts to window size

## Implementation Details
- Use Matter.Engine, Matter.World, Matter.Bodies, Matter.Render
- Create ground and walls as static bodies
- Spawn shapes at random positions above the table
- Add mouse constraint for drag interaction
- Implement spawn functions for each shape type
- Add keyboard event listeners for shortcuts
- Color palette: Red, Orange, Yellow, Green, Blue, Purple, Pink, Cyan
