---
code: PLAN.EX-000091
nb: PLAN
type: EX
name: car-portfolio-final-spec
status: active
updated: 2026-04-09
summary: Final, robust specification for the car portfolio website
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-09
pinned: 0
source: agent
---

# car-portfolio-final-spec

## Car Portfolio Website Specification (car_portfolio_gemma4_e4b-it.html)

**Goal:** Create a single, self-contained, professional car portfolio website.

**Structure:** Must include standard HTML5 boilerplate (`<!DOCTYPE html>`, `<html>`, `<head>`, `<body>`, `</html>`).

**Styling (CSS):** Must be entirely inline within `<style>` tags in the `<head>`. Use a dark, high-contrast theme (e.g., black background, white/grey text, electric blue/red accents). Use CSS Grid for the main layout and Flexbox for component alignment.

**Components & Layout:**
1.  **Navigation Bar:** Fixed at the top. Links: Home, Portfolio, About, Contact. Must use smooth scrolling via JavaScript.
2.  **Hero Section:** Full viewport height. Large, impactful headline and a placeholder for a hero image.
3.  **Portfolio Section:** The core. Must display 4 distinct car entries using responsive cards (CSS Grid). Each card must contain a placeholder image, a car model name, a short description, and a call-to-action button.
4.  **About Section:** Contains a placeholder for a profile picture and a short biography.
5.  **Contact Section:** A simple, styled form placeholder (Name, Email, Message).
6.  **Footer:** Contains copyright information.

**Interactivity (JavaScript):**
*   Implement smooth scrolling for navigation links.
*   Add subtle hover effects to the portfolio cards (e.g., slight lift/shadow change).

**Data:** Use placeholder data for all cars and text content. The entire file must be one HTML document.
