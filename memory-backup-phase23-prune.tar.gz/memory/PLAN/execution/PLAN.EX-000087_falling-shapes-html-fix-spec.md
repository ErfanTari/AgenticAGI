---
code: PLAN.EX-000087
nb: PLAN
type: EX
name: falling_shapes.html fix spec
status: active
updated: 2026-04-09
summary: Specification to fix Three.js import and animation loop in falling_shapes.html
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-09
pinned: 0
source: agent
---

# falling_shapes.html fix spec

The file `workspace/falling_shapes.html` has two issues to be corrected:

1.  **Three.js Import URL:** The current import URL `https://unpkg.com/three@0.160.0/build/three.min.js` is a non-module (UMD) build. It needs to be replaced with the ES module build URL: `https://unpkg.com/three@0.160.0/build/three.module.js`.

2.  **Animation Loop Initialization:** The `init()` function currently calls `animate()` directly, which can lead to `currentTime` being `undefined` and causing `NaN` physics. The direct call to `animate()` within the `init()` function must be replaced with `requestAnimationFrame(animate)` to ensure proper animation loop setup.
