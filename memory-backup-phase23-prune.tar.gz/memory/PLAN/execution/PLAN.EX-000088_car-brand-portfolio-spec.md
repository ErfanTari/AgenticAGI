---
code: PLAN.EX-000088
nb: PLAN
type: EX
name: car-brand-portfolio-spec
status: active
updated: 2026-04-09
summary: Specification for a single-file HTML car brand portfolio
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-09
pinned: 0
source: agent
---

# car-brand-portfolio-spec

## Car Brand Portfolio (index.html)

Create a single self-contained HTML file for a car brand portfolio. The file will include inline CSS for styling and basic JavaScript for any interactive elements (e.g., a simple image carousel or navigation toggle).

### General Structure:
*   **DOCTYPE** and **HTML** structure with `lang="en"`.
*   **Head**: Title, meta tags (charset, viewport), and inline `<style>` tag.
*   **Body**: Main content with semantic HTML5 elements.

### Sections:
1.  **Header (`<header>`):**
    *   Brand Logo/Name (e.g., 'ELEGANT AUTO').
    *   Navigation (`<nav>`): Links for Home, Models, About, Contact.

2.  **Hero Section (`<section class="hero">`):**
    *   Large background image of a premium car.
    *   Overlay text: "Experience Unrivaled Luxury" and a call to action button: "Explore Models".

3.  **Models Section (`<section class="models">`):**
    *   Title: "Our Exclusive Collection".
    *   Grid layout for 3-4 car models.
    *   Each model card will include:
        *   Image of the car.
        *   Model Name (e.g., 'Aura GT', 'Velocity X').
        *   Short description.
        *   "Learn More" button.

4.  **About Section (`<section class="about">`):**
    *   Title: "About ELEGANT AUTO".
    *   Paragraphs about the brand's history, vision, and commitment to excellence.

5.  **Contact Section (`<section class="contact">`):**
    *   Title: "Get in Touch".
    *   Contact form (Name, Email, Message).
    *   Contact information (Phone, Email, Address).
    *   Social media links (icons if possible, otherwise text links).

6.  **Footer (`<footer>`):**
    *   Copyright information.
    *   Quick links (Privacy Policy, Terms of Service - placeholders).

### Styling (Inline CSS):
*   **Colors:** A professional and elegant palette (e.g., dark grays, silver, gold accents).
*   **Typography:** Modern, clean sans-serif fonts.
*   **Layout:** Flexbox and CSS Grid for responsive design.
*   **Responsive Design:** Media queries for mobile responsiveness (e.g., stacking elements on smaller screens, adjusting font sizes).
*   **Hover Effects:** Subtle hover effects on buttons and navigation links.

### Interactivity (Inline JavaScript - if necessary for basic features):
*   Toggle navigation menu for mobile screens (hamburger icon).
*   Smooth scrolling for navigation links.

### Placeholder Content:
*   Use placeholder images for cars (e.g., from `picsum.photos` or generic car images).
*   Dummy text for descriptions and about section.

### Goal:
Produce a visually appealing, responsive, and functional single-file HTML portfolio that can serve as a strong foundation for a car brand's online presence.
