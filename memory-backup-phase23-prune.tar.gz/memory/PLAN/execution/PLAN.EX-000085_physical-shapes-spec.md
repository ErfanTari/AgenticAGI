---
code: PLAN.EX-000085
nb: PLAN
type: EX
name: physical-shapes-spec
status: active
updated: 2026-04-09
summary: Physics-based 3D shapes falling and bouncing simulation
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-09
pinned: 0
source: agent
---

# physical-shapes-spec

## Physical Shape 3D Simulation

### Libraries
- Load Three.js r160 from unpkg CDN: https://unpkg.com/three@0.160.0/build/three.min.js
- Load Cannon.js physics engine from cdnjs: https://cdnjs.cloudflare.com/ajax/libs/cannon.js/0.6.2/cannon.min.js
- Load OrbitControls from Three.js examples CDN

### Visual Features
- Scene with sky-blue background gradient
- Ground plane with grid texture
- Multiple 3D shapes: spheres (balls), cubes, cylinders, cones
- Random colors for each shape (vibrant palette)
- Shadows enabled for depth perception
- Ambient light + directional light for realistic shading

### Physics Setup
- Use Cannon.js world with gravity: -9.82 m/s²
- Ground: static plane with restitution (bounciness) 0.7
- Shapes: dynamic bodies with mass 1-5kg
- Collision detection enabled
- Shapes spawn at random positions above camera (y: 20-40)
- Initial velocity: small random downward force

### Interaction Model
- OrbitControls for mouse rotation, zoom, pan
- Auto-rotation enabled for demo effect
- Click to spawn new shapes
- Spacebar to reset all shapes to sky

### Animation Loop
- Sync Three.js renderer with Cannon.js physics step (1/60s)
- Update mesh positions/quaternions from physics bodies
- 60 FPS target with requestAnimationFrame
- Auto-spawn new shapes every 2 seconds if count < 50

### Layout
- Full viewport canvas (no margins)
- Overlay UI: shape count, FPS counter, instructions
- Responsive resize handler

### Shape Types
1. Sphere: radius 0.5-1.5, random color
2. Box: size 1-2, random color
3. Cylinder: radius 0.5-1, height 1-2
4. Cone: radius 0.5-1, height 1.5-2.5

### Color Palette
- Use HSL for vibrant colors: hue 0-360 random, saturation 70-100%, lightness 50-70%
