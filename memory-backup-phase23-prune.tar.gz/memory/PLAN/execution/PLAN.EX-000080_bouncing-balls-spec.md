---
code: PLAN.EX-000080
nb: PLAN
type: EX
name: bouncing-balls-spec
status: failed
updated: 2026-04-09
summary: 3D bouncing balls simulation
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-08
pinned: 0
source: agent
---

# bouncing-balls-spec

## 3D Bouncing Balls Simulation

## Libraries
- Load Three.js r160 from unpkg CDN: https://unpkg.com/three@0.160.0/build/three.min.js
- Load OrbitControls from examples/jsm/controls/OrbitControls.js

## Visual Features
- Canvas fills the entire viewport
- 50 colorful balls with random colors from a vibrant palette
- Each ball has a random radius between 5-15 units
- Balls bounce realistically off the boundaries of a 100x100x100 cube
- Smooth physics with velocity and gravity effects
- Soft shadows on the floor
- Ambient and directional lighting for depth

## Physics
- Each ball has position (x,y,z) and velocity (vx,vy,vz)
- Gravity pulls balls downward (vy decreases by 0.5 per frame)
- Balls bounce off walls with 0.8 restitution (energy loss)
- Floor collision at y = -50 with bounce
- Ball-to-ball collision detection and elastic collision response

## Interaction
- OrbitControls enabled for camera rotation and zoom
- Mouse drag to rotate view
- Scroll to zoom in/out
- Click and drag to pan

## Implementation
- Use BufferGeometry for efficient rendering
- Use MeshPhongMaterial for realistic ball appearance
- Animation loop using requestAnimationFrame
- Collision detection using sphere-sphere distance check
- Color palette: red, orange, yellow, green, blue, purple, pink, cyan
