---
code: PLAN.EX-000084
nb: PLAN
type: EX
name: physics-shapes-spec
status: active
updated: 2026-04-09
summary: 3D physics simulation with falling shapes
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-09
pinned: 0
source: agent
---

# physics-shapes-spec

## 3D Physics Shapes Simulation

### Libraries
- Load Three.js r160 from https://unpkg.com/three@0.160.0/build/three.min.js
- Load Cannon-es physics engine from https://unpkg.com/cannon-es@0.20.0/dist/cannon-es.min.js
- Load OrbitControls from https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js (use module import)

### Visual Features
- Create a scene with sky-blue background color (#87CEEB)
- Ground plane: large gray rectangle (100x100 units) with grid texture
- Camera positioned at height 30, looking down at angle 45 degrees
- Ambient light + directional sunlight with shadows enabled
- Render shadow map for realistic bouncing visualization

### 3D Shapes to Generate (50 small objects)
1. **Spheres** (20): Random colors, radius 0.3-0.6 units
2. **Cubes** (15): Random colors, size 0.4-0.8 units
3. **Cylinders** (10): Random colors, radius 0.2-0.4, height 0.5-1.0
4. **Cones** (5): Random colors, radius 0.3-0.5, height 0.8-1.2

### Physics Configuration (Cannon-es)
- Gravity: -9.8 m/s² (standard Earth gravity)
- Material friction: 0.5
- Restitution (bounciness): 0.7 for ground, 0.6 for objects
- Objects spawn at random x/z positions between -20 to +20, y=30-50
- Each object has random initial velocity slightly downward

### Interaction Model
- Mouse drag to rotate camera (OrbitControls)
- Scroll wheel for zoom in/out
- Press 'R' key to reset all shapes (respawn from sky)
- Press 'S' to spawn 10 new random shapes

### Animation Loop
- Update physics world at 60fps (fixed timestep 1/60)
- Sync Three.js meshes with Cannon-es bodies each frame
- Use requestAnimationFrame for smooth rendering

### Color Scheme
- Objects: Random vibrant colors using HSL (hue 0-360, saturation 70%, lightness 50%)
- Ground: Neutral gray (#808080)
- Sky: Light blue gradient effect

### Technical Details
- Use BufferGeometry for performance with many objects
- Enable shadowMap on renderer (PCFSoftShadowMap)
- Physics world step with fixed timestep for consistency
- Collision detection built into Cannon-es
