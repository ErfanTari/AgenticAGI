---
code: PLAN.EX-000090
nb: PLAN
type: EX
name: car-portfolio-spec
status: active
updated: 2026-04-09
summary: Spec for car portfolio website
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-09
pinned: 0
source: agent
---

# car-portfolio-spec

## Car Portfolio Website

Create a single self-contained HTML file named **car_portfolio_OSS_120b.html** showcasing a portfolio of cars. The page should include:

- A responsive navigation bar with links: Home, Gallery, Specs, Contact.
- A hero section with a background image of a sleek car and a tagline.
- A gallery section displaying at least six car cards in a responsive grid. Each card shows a car image, model name, year, and a short description. Use placeholder images from https://picsum.photos/ (e.g., https://picsum.photos/seed/car1/400/300).
- A specs section with a table comparing three car models on attributes like Engine, Horsepower, Torque, Price.
- A contact form with fields: Name, Email, Message and a submit button (no backend needed, just a placeholder alert on submit).
- Footer with social media icons (use Font Awesome CDN) and copyright.

### Technical Details
- Load **Bootstrap 5** CSS and JS from CDN for layout and responsiveness.
- Load **Font Awesome 6** for icons via CDN.
- Include a small custom CSS block inside `<style>` for additional styling (card hover effect, hero overlay, etc.).
- Include a small custom JS block inside `<script>` to handle the contact form submission (prevent default and show `alert('Message sent!')`).
- Ensure the page is mobile-friendly, using Bootstrap grid classes.
- Use semantic HTML5 elements (`<header>`, `<nav>`, `<section>`, `<footer>`).
- Add meta viewport tag for proper scaling.
- Provide alt text for all images.

The spec is concise but detailed enough for generation.

