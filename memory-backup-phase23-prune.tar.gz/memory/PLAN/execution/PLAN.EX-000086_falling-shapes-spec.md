---
code: PLAN.EX-000086
nb: PLAN
type: EX
name: falling-shapes-spec
status: active
updated: 2026-04-09
summary: 3D falling shapes simulation with Three.js
importance_score: 0
utility_score: 0
usage_count: 0
decay_rate: 0.1
active_page: 1
confidence: 1
last_accessed: 2026-04-09
pinned: 0
source: agent
---

# falling-shapes-spec

## 3D Falling Shapes Simulation

Load Three.js r160 from unpkg CDN: https://unpkg.com/three@0.160.0/build/three.min.js
Load OrbitControls from: https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js

## Visual Features
- Scene with dark gradient background (deep blue to black)
- 100 small 3D shapes falling from top to bottom
- Shape types: cubes, spheres, tetrahedrons, octahedrons
- Random colors: vibrant palette (cyan, magenta, yellow, lime, orange)
- Each shape has random size (0.3 to 0.8 units)
- Shapes rotate slowly while falling

## Physics & Animation
- Gravity simulation: shapes accelerate downward
- Bounce off floor with energy loss (0.7 restitution)
- Random initial positions spread across scene width
- Random initial velocities for variety
- Smooth animation using requestAnimationFrame

## Camera & Controls
- PerspectiveCamera positioned at (0, 30, 50)
- OrbitControls for mouse interaction (rotate, zoom, pan)
- Auto-rotation enabled for passive viewing

## Floor
- GridHelper for depth reference
- Subtle reflective plane at y=0

## Interaction
- Click to spawn new shapes
- Mouse drag to rotate camera
- Scroll to zoom

## Technical Details
- BufferGeometry for performance
- InstancedMesh not used for individual rotation control
- Scene bounds: x: -30 to 30, z: -30 to 30, y: 0 to 60
- Auto-reset shapes when they fall below floor
